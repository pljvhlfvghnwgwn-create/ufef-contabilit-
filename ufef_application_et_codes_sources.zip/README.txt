UFEF — FICHE DE RENSEIGNEMENT DU MEMBRE
=========================================

CONTENU
- ufef_fiche_renseignement_membre.html : application autonome (HTML, CSS et JavaScript intégrés).
- sources/style.css : styles CSS extraits pour lecture/modification.
- sources/app.js : code JavaScript extrait pour lecture/modification.
- sources/README_sources.txt : explication des fichiers source.
- README.txt : instructions d’utilisation.

UTILISATION
1. Ouvrir ufef_fiche_renseignement_membre.html dans un navigateur récent.
2. Renseigner les champs et ajouter la photo du membre.
3. Cliquer sur « Enregistrer sur cet appareil » pour enregistrer localement dans ce navigateur.
4. Utiliser « Imprimer / Enregistrer en PDF » pour imprimer ou produire un PDF.

IMPORTANT
Cette application est une fiche individuelle locale, pas une base de données en ligne.
Les données restent dans le stockage local du navigateur et ne sont pas synchronisées entre appareils.
Les fichiers CSS et JavaScript séparés sont des copies de référence : l’application HTML principale contient déjà ces codes intégrés. Modifier les fichiers séparés ne modifie pas automatiquement le HTML principal.
Protégez les photos et renseignements personnels des membres.
