Le fichier HTML principal est autonome et contient déjà son CSS et son JavaScript intégrés.
style.css et app.js sont des copies séparées du code pour consultation et modification.
Si vous modifiez ces fichiers séparés, ces modifications ne sont pas automatiquement réinjectées dans le HTML principal.
