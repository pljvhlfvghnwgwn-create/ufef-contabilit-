// JavaScript extrait de l'application HTML autonome UFEF


const fields=()=>Array.from(document.querySelectorAll('[data-field]'));
const photoInput=document.getElementById('photoInput'), photoBox=document.getElementById('photoBox');
let photoData='';
photoInput.addEventListener('change',e=>{
 const f=e.target.files&&e.target.files[0]; if(!f)return;
 if(!f.type.startsWith('image/')){alert('Veuillez choisir une image.');return;}
 const reader=new FileReader();
 reader.onload=()=>{const im=new Image();im.onload=()=>{
  const max=500,scale=Math.min(1,max/Math.max(im.width,im.height));
  const c=document.createElement('canvas');c.width=Math.round(im.width*scale);c.height=Math.round(im.height*scale);
  c.getContext('2d').drawImage(im,0,0,c.width,c.height);photoData=c.toDataURL('image/jpeg',.78);renderPhoto();
 };im.src=reader.result;};reader.readAsDataURL(f);
});
function renderPhoto(){photoBox.innerHTML='';if(photoData){const im=document.createElement('img');im.src=photoData;im.alt='Photo du membre';photoBox.appendChild(im);}else photoBox.innerHTML='<span>Cliquer pour ajouter<br>ou prendre une photo</span>';}
function getData(){const d={photo:photoData,fields:{}};fields().forEach(el=>{d.fields[el.dataset.field]=el.type==='checkbox'?el.checked:el.value;});return d;}
function setData(d){if(!d||!d.fields)return;fields().forEach(el=>{const v=d.fields[el.dataset.field];if(el.type==='checkbox')el.checked=!!v;else el.value=v??'';});photoData=d.photo||'';renderPhoto();}
function saveLocal(){try{localStorage.setItem('ufef_fiche_membre_vierge_data',JSON.stringify(getData()));alert('Fiche enregistrée sur cet appareil.');}catch(e){alert('Enregistrement impossible. Téléchargez une copie HTML ou imprimez en PDF.');}}
function loadLocal(){try{const d=JSON.parse(localStorage.getItem('ufef_fiche_membre_vierge_data')||'null');if(!d){alert('Aucune fiche enregistrée sur cet appareil.');return;}setData(d);alert('Fiche récupérée.');}catch(e){alert('Impossible de récupérer la fiche.');}}
function clearForm(){if(!confirm('Effacer tous les renseignements saisis dans cette fiche ?'))return;fields().forEach(el=>{if(el.type==='checkbox')el.checked=false;else el.value='';});photoData='';photoInput.value='';renderPhoto();}
function downloadBlank(){const clone=document.documentElement.cloneNode(true);clone.querySelectorAll('input[data-field],textarea[data-field]').forEach(el=>{el.value='';el.removeAttribute('value');});clone.querySelectorAll('input[type=checkbox]').forEach(el=>el.checked=false);const blob=new Blob(['<!doctype html>\\n'+clone.outerHTML],{type:'text/html;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='UFEF_fiche_renseignement_membre_vierge.html';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
